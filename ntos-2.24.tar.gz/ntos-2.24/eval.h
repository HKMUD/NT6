#ifndef FLUFF_EVAL_H
#define FLUFF_EVAL_H
extern int outoftime;
INLINE void set_eval(int time);
INLINE int get_eval();
#endif
