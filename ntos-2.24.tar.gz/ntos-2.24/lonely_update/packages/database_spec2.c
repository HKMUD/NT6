
#include "spec.h"

mixed set(string, mixed, ...);
mixed set_temp(string, mixed, ...);
mixed query(string, ...);
mixed query_temp(string, ...);
mixed addn(string, int, void | object);
mixed addn_temp(string, int, void | object);
void delete(string, ...);
void delete_temp(string, ...);
