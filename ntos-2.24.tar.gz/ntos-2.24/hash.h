#ifndef HASH_H
#define HASH_H

/*
 * hash.c
 */
unsigned int whashstr (const char *);

#endif
