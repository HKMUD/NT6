#include "spec.h"
int milli_clock();
void luan(string);
string hash(string,string);
#ifdef EPOLL
string epoll();
#endif
