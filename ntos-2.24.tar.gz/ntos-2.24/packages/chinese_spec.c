
#include "spec.h"

string B2G(string);
string G2B(string);
string bg5cc(string);
string cwrap(string, void | int, void | int);
