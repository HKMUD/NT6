
#include "spec.h"

mixed set(string, mixed, void | object);
mixed set_temp(string, mixed, void | object);
mixed query(string, void | object);
mixed query_temp(string, void | object);
mixed addn(string, int, void | object);
mixed addn_temp(string, int, void | object);
void delete(string, void | object);
void delete_temp(string, void | object);
