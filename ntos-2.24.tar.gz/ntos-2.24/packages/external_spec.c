#include "spec.h"

int external_start(int, string | string *, string | function, string | function, string | function | void);
