
#include "spec.h"

mixed count(mixed, string, mixed);
