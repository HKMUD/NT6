
#include "spec.h"

string ansi(string);
string ansi_part(string);

string remove_ansi(string);
string remove_bg_ansi(string);
string kill_repeat_ansi(string);

int noansi_strlen(string);
