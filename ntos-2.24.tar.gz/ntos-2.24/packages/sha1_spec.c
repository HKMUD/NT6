#include "spec.h"

string sha1(string);
