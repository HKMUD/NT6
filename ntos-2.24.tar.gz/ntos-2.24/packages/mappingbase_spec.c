
#include "spec.h"

mixed mb_set(string, mixed, ...);
mixed mb_query(string, ...);
void mb_delete(string, ...);
