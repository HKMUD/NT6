#ifndef SOCKET_ERR_H
#define SOCKET_ERR_H
/*
 * socket_err.h
 */
extern const char *error_strings[];

#endif
