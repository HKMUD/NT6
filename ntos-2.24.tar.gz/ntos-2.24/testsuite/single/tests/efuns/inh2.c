inherit "/single/tests/efuns/inh1.c";
