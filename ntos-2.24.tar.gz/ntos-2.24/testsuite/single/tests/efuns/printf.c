void do_tests() {
    // more complete testing done under sprintf()
    printf("Printf test.\n");
}
