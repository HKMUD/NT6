void do_tests() {
    /* tests later */
}
