void do_tests() {
    ASSERT(stringp(malloc_status()));
}
