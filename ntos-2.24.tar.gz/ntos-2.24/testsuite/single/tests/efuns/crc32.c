void do_tests() {
    ASSERT(catch(crc32(0)));
    ASSERT(intp(crc32("foobarbazz")));
}

