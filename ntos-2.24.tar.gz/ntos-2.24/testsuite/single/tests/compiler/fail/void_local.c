void foo() {
    void x;
}
