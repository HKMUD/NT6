void foo() {
}

void foo() {
}
