void foo() {
    break;
}
