TYPETEST

void foo() {
    int x = "hi";
}
