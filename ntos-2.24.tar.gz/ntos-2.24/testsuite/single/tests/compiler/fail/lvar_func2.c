void foo() {
    int x;
    (: x + 1 :);
}
